This repo expects:
  gradle/wrapper/gradle-wrapper.jar

We include the official Gradle 9.3.1 wrapper jar so ./gradlew works immediately.
