rootProject.name = "zakum"

include(
  "zakum-api",
  "zakum-core",
  "zakum-battlepass",
  "zakum-crates",
  "zakum-pets",
  "zakum-miniaturepets"
)

