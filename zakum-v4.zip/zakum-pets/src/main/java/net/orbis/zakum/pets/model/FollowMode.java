package net.orbis.zakum.pets.model;

public enum FollowMode {
  AI,
  TELEPORT
}
