package net.orbis.zakum.pets.state;

public final class PetPlayerState {
  public String selectedPetId = "";
  public int level = 1;
  public long xp = 0;
}
