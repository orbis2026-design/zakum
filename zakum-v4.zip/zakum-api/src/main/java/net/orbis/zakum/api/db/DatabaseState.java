package net.orbis.zakum.api.db;

public enum DatabaseState {
  ONLINE,
  OFFLINE
}
