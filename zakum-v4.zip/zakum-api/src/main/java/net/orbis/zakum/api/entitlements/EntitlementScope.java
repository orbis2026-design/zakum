package net.orbis.zakum.api.entitlements;

public enum EntitlementScope {
  SERVER,
  NETWORK
}
