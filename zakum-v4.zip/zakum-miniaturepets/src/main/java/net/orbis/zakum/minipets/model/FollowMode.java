package net.orbis.zakum.minipets.model;

public enum FollowMode {
  AI,
  TELEPORT
}
