package net.orbis.zakum.minipets.state;

public final class MiniPetPlayerState {
  public String petId = "";
  public boolean hat = false;
  public boolean ride = false;
}
